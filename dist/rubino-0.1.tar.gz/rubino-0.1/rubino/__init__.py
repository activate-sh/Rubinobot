from client import Client

__version__ = '0.1'
__author__ = 'amirali irvany'
__github__ = 'https://github.com/activate-sh'
