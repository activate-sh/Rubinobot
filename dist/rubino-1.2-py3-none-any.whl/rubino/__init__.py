from .client import Client

__version__ = '1.2'
__author__ = 'amirali irvany'
__github__ = 'https://github.com/activate-sh'
